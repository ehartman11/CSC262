﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

/*
Create a GUI that allows input of a number between 1 and 10,000.
Create an array of integers where the size is based on the number that the user input.
Generate random numbers to fill the array.
Use performance timing to see how long it takes to generate the numbers.
Use performance timing to see how long it takes to sort the numbers.
Make sure to screen record the performance testing and provide it in your video demonstration.
*/

namespace Unit_Testing
{
    public partial class Form1 : Form
    {
        private Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        int checkInput()
        {

            if (int.TryParse(textBox1.Text, out int result)) {
                if (result >= 1 && result <= 10000) { return result; }
            }

            MessageBox.Show("Not a valid integer. Choose a number between 1 and 10,000");
            return 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] numbersArray = new int[checkInput()];
            
            if (numbersArray.Length != 0) {
                var watch = Stopwatch.StartNew();
                for (int i = 0; i < numbersArray.Length; i++)
                {
                    numbersArray[i] = rand.Next(0, 100000);
                }
                watch.Stop();
                long genTime = watch.ElapsedMilliseconds;
             
                watch = Stopwatch.StartNew();
                Array.Sort(numbersArray);
                watch.Stop();
                long sortTime = watch.ElapsedMilliseconds;

                resultLabel.Text = "Array Generated in: " + genTime + " milliseconds";
                resultLabel2.Text = "Array Sorted in: " + sortTime + " milliseconds";
                numbersArray = null;
            }
        }
    }
}
