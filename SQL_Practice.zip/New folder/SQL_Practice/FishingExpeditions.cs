﻿using System.Data.SQLite;
using System;
using System.Windows.Forms;

namespace FishingExpeditions.Data
{
	public static class FishingDatabase
	{
		public static void Initialize(string dbPath)
		{
			string connectionString = $"Data Source={dbPath};Version=3;";

			using (var conn = new SQLiteConnection(connectionString))
			{
				conn.Open();

				string createTables = @"
					DROP TABLE IF EXISTS Boats;
					DROP TABLE IF EXISTS Schedule;
					DROP TABLE IF EXISTS Departure;
					DROP TABLE IF EXISTS Arrival;
					DROP VIEW IF EXISTS ScheduleSummary;	
					DROP VIEW IF EXISTS DepartureSummary;
					DROP VIEW IF EXISTS ArrivalSummary;

					CREATE TABLE IF NOT EXISTS Boats (
						Id INTEGER PRIMARY KEY AUTOINCREMENT,
						Name TEXT NOT NULL,
						Capacity REAL NOT NULL,			
						Captain TEXT NOT NULL,
						MaintenanceDue Datetime NOT NULL
					);

					CREATE TABLE IF NOT EXISTS Schedule (
						Id INTEGER PRIMARY KEY AUTOINCREMENT,
						BoatId Integer NOT NULL,
						Date TEXT   NOT NULL,
						Destination Integer NOT NULL,
						GearProvided Bool NOT NULL,
						FOREIGN KEY (BoatId) REFERENCES Boats(Id)
					);

					CREATE TABLE IF NOT EXISTS Departure (
						Id INTEGER PRIMARY KEY AUTOINCREMENT,
						BoatId INTEGER NOT NULL,
						ScheduleId INTEGER NOT NULL,
						Pier Integer NOT NULL,
						Berth Integer NOT NULL,
						DepartureTime TEXT NOT NULL,
						FOREIGN KEY (BoatId) REFERENCES Boats(Id),
						FOREIGN KEY (ScheduleId) REFERENCES Schedule(Id)
					);
			
					CREATE TABLE IF NOT EXISTS Arrival (
						Id INTEGER PRIMARY KEY AUTOINCREMENT,
						BoatId INTEGER NOT NULL,
						ScheduleId INTEGER NOT NULL,
						Pier Integer NOT NULL,
						Berth Integer NOT NULL,
						ArrivalTime TEXT NOT NULL,
						FOREIGN KEY (BoatId) REFERENCES Boats(Id),
						FOREIGN KEY (ScheduleId) REFERENCES Schedule(Id)
					);
				";
				using (var cmd = new SQLiteCommand(createTables, conn))
				{
					cmd.ExecuteNonQuery();
				}
			}

			using (var conn = new SQLiteConnection(connectionString))
			{
				conn.Open();
				string insertBoat = @"
				INSERT INTO Boats (Name, Capacity, Captain, MaintenanceDue) 
				VALUES 
					('Salty Dog', 10, 'Captain Jack Sparrow', '2025-12-01'),
					('Wind Dancer', 15, 'Captain Nemo', '2026-01-14'),
					('The Codfather', 12, 'Captain Blackbeard', '2026-06-01'),
					('Island Time', 10, 'Captain Morgan', '2025-08-01')";


                string insertSchedule = @"
                INSERT INTO Schedule (BoatId, Date, Destination, GearProvided)
				VALUES 
					(1, '2025-04-29', 1, False),
					(2, '2025-04-29', 2, True),
					(3, '2025-04-30', 1, True),
					(4, '2025-04-30', 2, True);";

				string insertDeparture = @"
				INSERT INTO Departure (BoatId, ScheduleId, Pier, Berth, DepartureTime)
				VALUES 
					(1, 1, 1, 1, '0800'),
					(2, 2, 2, 1, '1000'),
					(3, 3, 1, 2, '0600'),
					(4, 4, 2, 2, '1400');";

				string insertArrival = @"
				INSERT INTO Arrival (BoatId, ScheduleId, Pier, Berth, ArrivalTime)
				VALUES 
					(1, 1, 1, 1, '1300'),
					(2, 2, 2, 1, '1700'),
					(3, 3, 1, 2, '1200'),
					(4, 4, 2, 2, '1900');";
				
				using (var cmd = new SQLiteCommand(insertBoat, conn))
				{
					cmd.ExecuteNonQuery();
				}
                using (var cmd = new SQLiteCommand(insertSchedule, conn))
                {
                    cmd.ExecuteNonQuery();
                }
                using (var cmd = new SQLiteCommand(insertDeparture, conn))
                {
                    cmd.ExecuteNonQuery();
                }
                using (var cmd = new SQLiteCommand(insertArrival, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }

			using (var conn = new SQLiteConnection(connectionString))
			{
				conn.Open();
                var views = new string[]
				{
					@"CREATE VIEW IF NOT EXISTS ScheduleSummary AS
					SELECT 
						Boats.Name, 
						Schedule.Date, 
						Schedule.Destination, 
						Schedule.GearProvided
					FROM Boats
					JOIN Schedule ON Boats.Id = Schedule.BoatId",
                    
					@"CREATE VIEW IF NOT EXISTS DepartureSummary AS
					SELECT 
						Boats.Name, 
						Schedule.Date, 
						Departure.DepartureTime,	
						Departure.Pier, 
						Departure.Berth
					FROM Boats
					JOIN Schedule ON Boats.Id = Schedule.BoatId
					JOIN Departure ON Schedule.Id = Departure.ScheduleId", 
					
					@"CREATE VIEW IF NOT EXISTS ArrivalSummary AS
                    SELECT
                        Boats.Name,
                        Schedule.Date,
                        Arrival.ArrivalTime,
                        Arrival.Pier,
                        Arrival.Berth
                    FROM Boats
                    JOIN Schedule ON Boats.Id = Schedule.BoatId
                    JOIN Arrival ON Schedule.Id = Arrival.ScheduleId"
				};

				foreach (var view in views)
				{
					using (var cmd = new SQLiteCommand(view, conn))
					{
						cmd.ExecuteNonQuery();
					}
				}
            }

            Console.WriteLine("Database initialized with sample data.");
        }
	}
}
