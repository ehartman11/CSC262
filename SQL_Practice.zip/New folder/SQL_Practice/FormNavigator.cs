﻿using System.Windows.Forms;

public static class FormNavigator
    {
        public static void SwitchTo(Form currentForm, Form nextForm)
    {
        nextForm.Show();
        currentForm.Hide();
    }
}

