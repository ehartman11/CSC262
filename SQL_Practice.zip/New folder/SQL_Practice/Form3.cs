﻿using System;
using System.Windows.Forms;

namespace SQL_Practice
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            this.Load += Form3_Load;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            DataLoader.LoadData("FishingExpeditions.db", "DepartureSummary", departureGridView);
            DataLoader.LoadData("FishingExpeditions.db", "ArrivalSummary", arrivalGridView);
        }

        private void boatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNavigator.SwitchTo(this, new Form1());
            Console.WriteLine("Boats menu item clicked");
        }

        private void scheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNavigator.SwitchTo(this, new Form2());
            Console.WriteLine("Schedule menu item clicked");
        }
    }
}
