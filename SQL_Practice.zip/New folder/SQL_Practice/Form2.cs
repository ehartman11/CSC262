﻿using System;
using System.Windows.Forms;

namespace SQL_Practice
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.Load += Form2_Load;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            DataLoader.LoadData("FishingExpeditions.db", "ScheduleSummary", dataGridView1);
        }

        private void boatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNavigator.SwitchTo(this, new Form1());
            Console.WriteLine("Boats menu item clicked");
        }

        private void arrivalDepartureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNavigator.SwitchTo(this, new Form3());
            Console.WriteLine("Arrival/Departure menu item clicked");
        }
    }
}
