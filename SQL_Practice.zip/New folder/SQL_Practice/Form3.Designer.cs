﻿namespace SQL_Practice
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.departureGridView = new System.Windows.Forms.DataGridView();
            this.arrivalGridView = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.boatsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arrivalDepartureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.departureGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrivalGridView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // departureGridView
            // 
            this.departureGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.departureGridView.Location = new System.Drawing.Point(45, 29);
            this.departureGridView.Name = "departureGridView";
            this.departureGridView.Size = new System.Drawing.Size(677, 199);
            this.departureGridView.TabIndex = 0;
            // 
            // arrivalGridView
            // 
            this.arrivalGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.arrivalGridView.Location = new System.Drawing.Point(45, 245);
            this.arrivalGridView.Name = "arrivalGridView";
            this.arrivalGridView.Size = new System.Drawing.Size(677, 199);
            this.arrivalGridView.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.boatsToolStripMenuItem,
            this.scheduleToolStripMenuItem,
            this.arrivalDepartureToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(765, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // boatsToolStripMenuItem
            // 
            this.boatsToolStripMenuItem.Name = "boatsToolStripMenuItem";
            this.boatsToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.boatsToolStripMenuItem.Text = "Boats";
            this.boatsToolStripMenuItem.Click += new System.EventHandler(this.boatsToolStripMenuItem_Click);
            // 
            // scheduleToolStripMenuItem
            // 
            this.scheduleToolStripMenuItem.Name = "scheduleToolStripMenuItem";
            this.scheduleToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.scheduleToolStripMenuItem.Text = "Schedule";
            this.scheduleToolStripMenuItem.Click += new System.EventHandler(this.scheduleToolStripMenuItem_Click);
            // 
            // arrivalDepartureToolStripMenuItem
            // 
            this.arrivalDepartureToolStripMenuItem.Enabled = false;
            this.arrivalDepartureToolStripMenuItem.Name = "arrivalDepartureToolStripMenuItem";
            this.arrivalDepartureToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.arrivalDepartureToolStripMenuItem.Text = "Arrival/Departure";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 474);
            this.Controls.Add(this.arrivalGridView);
            this.Controls.Add(this.departureGridView);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.departureGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrivalGridView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView departureGridView;
        private System.Windows.Forms.DataGridView arrivalGridView;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem boatsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrivalDepartureToolStripMenuItem;
    }
}