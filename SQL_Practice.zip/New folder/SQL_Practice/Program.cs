﻿using System;
using System.Windows.Forms;
using FishingExpeditions.Data;

namespace SQL_Practice
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Initialize the database
            FishingDatabase.Initialize("FishingExpeditions.db");
            Application.Run(new Form1());
        }
    }
}
