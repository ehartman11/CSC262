﻿using System;
using System.Windows.Forms;

namespace SQL_Practice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataLoader.LoadData("FishingExpeditions.db", "Boats", dataGridView1);
            Console.WriteLine("Form1 loaded");
        }

        private void ScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNavigator.SwitchTo(this, new Form2());
            Console.WriteLine("Schedule menu item clicked");
        }

        private void ArrivalDepartureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormNavigator.SwitchTo(this, new Form3());
            Console.WriteLine("Arrival/Departure menu item clicked");
        }
    }
}
