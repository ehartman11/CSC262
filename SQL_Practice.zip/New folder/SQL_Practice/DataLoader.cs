﻿using System;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Data;

public static class DataLoader
{
    public static void LoadData(string dbPath, string tableName, DataGridView grid)
    {
        string connectionString = $"Data Source={dbPath};Version=3;";
        using (var conn = new SQLiteConnection(connectionString))
        {
            conn.Open();
            string query = $"SELECT * FROM {tableName}";
            using (var cmd = new SQLiteCommand(query, conn))
            {
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    grid.DataSource = dataTable;
                }
            }
        }
        Console.WriteLine($"Data loaded from {tableName} table in {dbPath} database.");
    }
}
