﻿namespace OOP
{
    partial class CharDisplayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SaveButton = new System.Windows.Forms.Button();
            this.EditLabel = new System.Windows.Forms.Button();
            this.NameLabel = new System.Windows.Forms.Label();
            this.ClassLabel = new System.Windows.Forms.Label();
            this.SpeciesLabel = new System.Windows.Forms.Label();
            this.LevelLabel = new System.Windows.Forms.Label();
            this.HitPointsLabel = new System.Windows.Forms.Label();
            this.StrengthLabel = new System.Windows.Forms.Label();
            this.DexterityLabel = new System.Windows.Forms.Label();
            this.ConstitutionLabel = new System.Windows.Forms.Label();
            this.IntelligenceLabel = new System.Windows.Forms.Label();
            this.WisdomLabel = new System.Windows.Forms.Label();
            this.CharismaLabel = new System.Windows.Forms.Label();
            this.AttributesLabel = new System.Windows.Forms.Label();
            this.ItemsLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CoinLabel = new System.Windows.Forms.Label();
            this.RemoveButton = new System.Windows.Forms.Button();
            this.strengthBox = new System.Windows.Forms.NumericUpDown();
            this.IntelligenceBox = new System.Windows.Forms.NumericUpDown();
            this.DexterityBox = new System.Windows.Forms.NumericUpDown();
            this.ConstitutionBox = new System.Windows.Forms.NumericUpDown();
            this.WisdomBox = new System.Windows.Forms.NumericUpDown();
            this.CharismaBox = new System.Windows.Forms.NumericUpDown();
            this.NameLbl = new System.Windows.Forms.Label();
            this.ClassLbl = new System.Windows.Forms.Label();
            this.SpeciesLbl = new System.Windows.Forms.Label();
            this.LevelBox = new System.Windows.Forms.NumericUpDown();
            this.HpBox = new System.Windows.Forms.NumericUpDown();
            this.CoinBox = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.BackstoryBox = new System.Windows.Forms.RichTextBox();
            this.BondBox = new System.Windows.Forms.RichTextBox();
            this.NotesBox = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ItemsListBox = new System.Windows.Forms.ListBox();
            this.SpellsListBox = new System.Windows.Forms.ListBox();
            this.WeaponsListBox = new System.Windows.Forms.ListBox();
            this.ArmorListBox = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.strengthBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IntelligenceBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DexterityBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConstitutionBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WisdomBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CharismaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LevelBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HpBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoinBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(103, 10);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(75, 23);
            this.SaveButton.TabIndex = 0;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click_1);
            // 
            // EditLabel
            // 
            this.EditLabel.Location = new System.Drawing.Point(22, 10);
            this.EditLabel.Name = "EditLabel";
            this.EditLabel.Size = new System.Drawing.Size(75, 23);
            this.EditLabel.TabIndex = 1;
            this.EditLabel.Text = "Edit";
            this.EditLabel.UseVisualStyleBackColor = true;
            this.EditLabel.Click += new System.EventHandler(this.EditLabel_Click);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(33, 48);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(35, 13);
            this.NameLabel.TabIndex = 2;
            this.NameLabel.Text = "Name";
            // 
            // ClassLabel
            // 
            this.ClassLabel.AutoSize = true;
            this.ClassLabel.Location = new System.Drawing.Point(33, 74);
            this.ClassLabel.Name = "ClassLabel";
            this.ClassLabel.Size = new System.Drawing.Size(32, 13);
            this.ClassLabel.TabIndex = 3;
            this.ClassLabel.Text = "Class";
            // 
            // SpeciesLabel
            // 
            this.SpeciesLabel.AutoSize = true;
            this.SpeciesLabel.Location = new System.Drawing.Point(33, 100);
            this.SpeciesLabel.Name = "SpeciesLabel";
            this.SpeciesLabel.Size = new System.Drawing.Size(45, 13);
            this.SpeciesLabel.TabIndex = 24;
            this.SpeciesLabel.Text = "Species";
            // 
            // LevelLabel
            // 
            this.LevelLabel.AutoSize = true;
            this.LevelLabel.Location = new System.Drawing.Point(35, 126);
            this.LevelLabel.Name = "LevelLabel";
            this.LevelLabel.Size = new System.Drawing.Size(33, 13);
            this.LevelLabel.TabIndex = 25;
            this.LevelLabel.Text = "Level";
            // 
            // HitPointsLabel
            // 
            this.HitPointsLabel.AutoSize = true;
            this.HitPointsLabel.Location = new System.Drawing.Point(35, 156);
            this.HitPointsLabel.Name = "HitPointsLabel";
            this.HitPointsLabel.Size = new System.Drawing.Size(52, 13);
            this.HitPointsLabel.TabIndex = 26;
            this.HitPointsLabel.Text = "Hit Points";
            // 
            // StrengthLabel
            // 
            this.StrengthLabel.AutoSize = true;
            this.StrengthLabel.Location = new System.Drawing.Point(33, 214);
            this.StrengthLabel.Name = "StrengthLabel";
            this.StrengthLabel.Size = new System.Drawing.Size(47, 13);
            this.StrengthLabel.TabIndex = 27;
            this.StrengthLabel.Text = "Strength";
            // 
            // DexterityLabel
            // 
            this.DexterityLabel.AutoSize = true;
            this.DexterityLabel.Location = new System.Drawing.Point(32, 268);
            this.DexterityLabel.Name = "DexterityLabel";
            this.DexterityLabel.Size = new System.Drawing.Size(48, 13);
            this.DexterityLabel.TabIndex = 28;
            this.DexterityLabel.Text = "Dexterity";
            // 
            // ConstitutionLabel
            // 
            this.ConstitutionLabel.AutoSize = true;
            this.ConstitutionLabel.Location = new System.Drawing.Point(33, 294);
            this.ConstitutionLabel.Name = "ConstitutionLabel";
            this.ConstitutionLabel.Size = new System.Drawing.Size(62, 13);
            this.ConstitutionLabel.TabIndex = 29;
            this.ConstitutionLabel.Text = "Constitution";
            // 
            // IntelligenceLabel
            // 
            this.IntelligenceLabel.AutoSize = true;
            this.IntelligenceLabel.Location = new System.Drawing.Point(32, 241);
            this.IntelligenceLabel.Name = "IntelligenceLabel";
            this.IntelligenceLabel.Size = new System.Drawing.Size(61, 13);
            this.IntelligenceLabel.TabIndex = 30;
            this.IntelligenceLabel.Text = "Intelligence";
            // 
            // WisdomLabel
            // 
            this.WisdomLabel.AutoSize = true;
            this.WisdomLabel.Location = new System.Drawing.Point(33, 320);
            this.WisdomLabel.Name = "WisdomLabel";
            this.WisdomLabel.Size = new System.Drawing.Size(45, 13);
            this.WisdomLabel.TabIndex = 31;
            this.WisdomLabel.Text = "Wisdom";
            // 
            // CharismaLabel
            // 
            this.CharismaLabel.AutoSize = true;
            this.CharismaLabel.Location = new System.Drawing.Point(34, 346);
            this.CharismaLabel.Name = "CharismaLabel";
            this.CharismaLabel.Size = new System.Drawing.Size(50, 13);
            this.CharismaLabel.TabIndex = 32;
            this.CharismaLabel.Text = "Charisma";
            // 
            // AttributesLabel
            // 
            this.AttributesLabel.AutoSize = true;
            this.AttributesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttributesLabel.Location = new System.Drawing.Point(33, 186);
            this.AttributesLabel.Name = "AttributesLabel";
            this.AttributesLabel.Size = new System.Drawing.Size(51, 13);
            this.AttributesLabel.TabIndex = 33;
            this.AttributesLabel.Text = "Attributes";
            // 
            // ItemsLabel
            // 
            this.ItemsLabel.AutoSize = true;
            this.ItemsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemsLabel.Location = new System.Drawing.Point(207, 48);
            this.ItemsLabel.Name = "ItemsLabel";
            this.ItemsLabel.Size = new System.Drawing.Size(32, 13);
            this.ItemsLabel.TabIndex = 34;
            this.ItemsLabel.Text = "Items";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(207, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 44;
            this.label2.Text = "Spells";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(207, 290);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 45;
            this.label3.Text = "Weapons";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(208, 390);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 46;
            this.label4.Text = "Armor";
            // 
            // CoinLabel
            // 
            this.CoinLabel.AutoSize = true;
            this.CoinLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoinLabel.Location = new System.Drawing.Point(37, 385);
            this.CoinLabel.Name = "CoinLabel";
            this.CoinLabel.Size = new System.Drawing.Size(28, 13);
            this.CoinLabel.TabIndex = 50;
            this.CoinLabel.Text = "Coin";
            // 
            // RemoveButton
            // 
            this.RemoveButton.Location = new System.Drawing.Point(210, 10);
            this.RemoveButton.Name = "RemoveButton";
            this.RemoveButton.Size = new System.Drawing.Size(75, 23);
            this.RemoveButton.TabIndex = 51;
            this.RemoveButton.Text = "Remove";
            this.RemoveButton.UseVisualStyleBackColor = true;
            this.RemoveButton.Click += new System.EventHandler(this.RemoveButton_Click);
            // 
            // strengthBox
            // 
            this.strengthBox.Enabled = false;
            this.strengthBox.Location = new System.Drawing.Point(103, 212);
            this.strengthBox.Name = "strengthBox";
            this.strengthBox.Size = new System.Drawing.Size(45, 20);
            this.strengthBox.TabIndex = 52;
            // 
            // IntelligenceBox
            // 
            this.IntelligenceBox.Enabled = false;
            this.IntelligenceBox.Location = new System.Drawing.Point(103, 238);
            this.IntelligenceBox.Name = "IntelligenceBox";
            this.IntelligenceBox.Size = new System.Drawing.Size(45, 20);
            this.IntelligenceBox.TabIndex = 53;
            // 
            // DexterityBox
            // 
            this.DexterityBox.Enabled = false;
            this.DexterityBox.Location = new System.Drawing.Point(103, 266);
            this.DexterityBox.Name = "DexterityBox";
            this.DexterityBox.Size = new System.Drawing.Size(45, 20);
            this.DexterityBox.TabIndex = 54;
            // 
            // ConstitutionBox
            // 
            this.ConstitutionBox.Enabled = false;
            this.ConstitutionBox.Location = new System.Drawing.Point(101, 292);
            this.ConstitutionBox.Name = "ConstitutionBox";
            this.ConstitutionBox.Size = new System.Drawing.Size(47, 20);
            this.ConstitutionBox.TabIndex = 55;
            // 
            // WisdomBox
            // 
            this.WisdomBox.Enabled = false;
            this.WisdomBox.Location = new System.Drawing.Point(103, 318);
            this.WisdomBox.Name = "WisdomBox";
            this.WisdomBox.Size = new System.Drawing.Size(45, 20);
            this.WisdomBox.TabIndex = 56;
            // 
            // CharismaBox
            // 
            this.CharismaBox.Enabled = false;
            this.CharismaBox.Location = new System.Drawing.Point(103, 344);
            this.CharismaBox.Name = "CharismaBox";
            this.CharismaBox.Size = new System.Drawing.Size(45, 20);
            this.CharismaBox.TabIndex = 57;
            // 
            // NameLbl
            // 
            this.NameLbl.AutoSize = true;
            this.NameLbl.Location = new System.Drawing.Point(100, 48);
            this.NameLbl.Name = "NameLbl";
            this.NameLbl.Size = new System.Drawing.Size(45, 13);
            this.NameLbl.TabIndex = 58;
            this.NameLbl.Text = "ability_1";
            // 
            // ClassLbl
            // 
            this.ClassLbl.AutoSize = true;
            this.ClassLbl.Location = new System.Drawing.Point(100, 74);
            this.ClassLbl.Name = "ClassLbl";
            this.ClassLbl.Size = new System.Drawing.Size(45, 13);
            this.ClassLbl.TabIndex = 59;
            this.ClassLbl.Text = "ability_1";
            // 
            // SpeciesLbl
            // 
            this.SpeciesLbl.AutoSize = true;
            this.SpeciesLbl.Location = new System.Drawing.Point(100, 100);
            this.SpeciesLbl.Name = "SpeciesLbl";
            this.SpeciesLbl.Size = new System.Drawing.Size(45, 13);
            this.SpeciesLbl.TabIndex = 60;
            this.SpeciesLbl.Text = "ability_1";
            // 
            // LevelBox
            // 
            this.LevelBox.Enabled = false;
            this.LevelBox.Location = new System.Drawing.Point(100, 124);
            this.LevelBox.Name = "LevelBox";
            this.LevelBox.Size = new System.Drawing.Size(45, 20);
            this.LevelBox.TabIndex = 61;
            // 
            // HpBox
            // 
            this.HpBox.Enabled = false;
            this.HpBox.Location = new System.Drawing.Point(100, 154);
            this.HpBox.Name = "HpBox";
            this.HpBox.Size = new System.Drawing.Size(45, 20);
            this.HpBox.TabIndex = 62;
            // 
            // CoinBox
            // 
            this.CoinBox.Enabled = false;
            this.CoinBox.Location = new System.Drawing.Point(103, 383);
            this.CoinBox.Name = "CoinBox";
            this.CoinBox.Size = new System.Drawing.Size(45, 20);
            this.CoinBox.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(461, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 64;
            this.label1.Text = "Backstory";
            // 
            // BackstoryBox
            // 
            this.BackstoryBox.Enabled = false;
            this.BackstoryBox.Location = new System.Drawing.Point(464, 66);
            this.BackstoryBox.Name = "BackstoryBox";
            this.BackstoryBox.Size = new System.Drawing.Size(198, 108);
            this.BackstoryBox.TabIndex = 65;
            this.BackstoryBox.Text = "";
            // 
            // BondBox
            // 
            this.BondBox.Enabled = false;
            this.BondBox.Location = new System.Drawing.Point(464, 207);
            this.BondBox.Name = "BondBox";
            this.BondBox.Size = new System.Drawing.Size(198, 70);
            this.BondBox.TabIndex = 66;
            this.BondBox.Text = "";
            // 
            // NotesBox
            // 
            this.NotesBox.Enabled = false;
            this.NotesBox.Location = new System.Drawing.Point(464, 312);
            this.NotesBox.Name = "NotesBox";
            this.NotesBox.Size = new System.Drawing.Size(198, 178);
            this.NotesBox.TabIndex = 67;
            this.NotesBox.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(461, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 68;
            this.label5.Text = "Bonds";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(461, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 69;
            this.label6.Text = "Notes";
            // 
            // ItemsListBox
            // 
            this.ItemsListBox.FormattingEnabled = true;
            this.ItemsListBox.Location = new System.Drawing.Point(210, 66);
            this.ItemsListBox.Name = "ItemsListBox";
            this.ItemsListBox.Size = new System.Drawing.Size(214, 108);
            this.ItemsListBox.TabIndex = 70;
            // 
            // SpellsListBox
            // 
            this.SpellsListBox.FormattingEnabled = true;
            this.SpellsListBox.Location = new System.Drawing.Point(210, 208);
            this.SpellsListBox.Name = "SpellsListBox";
            this.SpellsListBox.Size = new System.Drawing.Size(214, 69);
            this.SpellsListBox.TabIndex = 71;
            // 
            // WeaponsListBox
            // 
            this.WeaponsListBox.FormattingEnabled = true;
            this.WeaponsListBox.Location = new System.Drawing.Point(210, 312);
            this.WeaponsListBox.Name = "WeaponsListBox";
            this.WeaponsListBox.Size = new System.Drawing.Size(214, 69);
            this.WeaponsListBox.TabIndex = 72;
            // 
            // ArmorListBox
            // 
            this.ArmorListBox.FormattingEnabled = true;
            this.ArmorListBox.Location = new System.Drawing.Point(210, 408);
            this.ArmorListBox.Name = "ArmorListBox";
            this.ArmorListBox.Size = new System.Drawing.Size(214, 82);
            this.ArmorListBox.TabIndex = 73;
            // 
            // CharDisplayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 502);
            this.Controls.Add(this.ArmorListBox);
            this.Controls.Add(this.WeaponsListBox);
            this.Controls.Add(this.SpellsListBox);
            this.Controls.Add(this.ItemsListBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.NotesBox);
            this.Controls.Add(this.BondBox);
            this.Controls.Add(this.BackstoryBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CoinBox);
            this.Controls.Add(this.HpBox);
            this.Controls.Add(this.LevelBox);
            this.Controls.Add(this.SpeciesLbl);
            this.Controls.Add(this.ClassLbl);
            this.Controls.Add(this.NameLbl);
            this.Controls.Add(this.CharismaBox);
            this.Controls.Add(this.WisdomBox);
            this.Controls.Add(this.ConstitutionBox);
            this.Controls.Add(this.DexterityBox);
            this.Controls.Add(this.IntelligenceBox);
            this.Controls.Add(this.strengthBox);
            this.Controls.Add(this.RemoveButton);
            this.Controls.Add(this.CoinLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ItemsLabel);
            this.Controls.Add(this.AttributesLabel);
            this.Controls.Add(this.CharismaLabel);
            this.Controls.Add(this.WisdomLabel);
            this.Controls.Add(this.IntelligenceLabel);
            this.Controls.Add(this.ConstitutionLabel);
            this.Controls.Add(this.DexterityLabel);
            this.Controls.Add(this.StrengthLabel);
            this.Controls.Add(this.HitPointsLabel);
            this.Controls.Add(this.LevelLabel);
            this.Controls.Add(this.SpeciesLabel);
            this.Controls.Add(this.ClassLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.EditLabel);
            this.Controls.Add(this.SaveButton);
            this.Name = "CharDisplayForm";
            this.Text = "CharDisplayForm";
            ((System.ComponentModel.ISupportInitialize)(this.strengthBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IntelligenceBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DexterityBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConstitutionBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WisdomBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CharismaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LevelBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HpBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CoinBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button EditLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label ClassLabel;
        private System.Windows.Forms.Label SpeciesLabel;
        private System.Windows.Forms.Label LevelLabel;
        private System.Windows.Forms.Label HitPointsLabel;
        private System.Windows.Forms.Label StrengthLabel;
        private System.Windows.Forms.Label DexterityLabel;
        private System.Windows.Forms.Label ConstitutionLabel;
        private System.Windows.Forms.Label IntelligenceLabel;
        private System.Windows.Forms.Label WisdomLabel;
        private System.Windows.Forms.Label CharismaLabel;
        private System.Windows.Forms.Label AttributesLabel;
        private System.Windows.Forms.Label ItemsLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label CoinLabel;
        private System.Windows.Forms.Button RemoveButton;
        private System.Windows.Forms.NumericUpDown strengthBox;
        private System.Windows.Forms.NumericUpDown IntelligenceBox;
        private System.Windows.Forms.NumericUpDown DexterityBox;
        private System.Windows.Forms.NumericUpDown ConstitutionBox;
        private System.Windows.Forms.NumericUpDown WisdomBox;
        private System.Windows.Forms.NumericUpDown CharismaBox;
        private System.Windows.Forms.Label NameLbl;
        private System.Windows.Forms.Label ClassLbl;
        private System.Windows.Forms.Label SpeciesLbl;
        private System.Windows.Forms.NumericUpDown LevelBox;
        private System.Windows.Forms.NumericUpDown HpBox;
        private System.Windows.Forms.NumericUpDown CoinBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox BackstoryBox;
        private System.Windows.Forms.RichTextBox BondBox;
        private System.Windows.Forms.RichTextBox NotesBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox ItemsListBox;
        private System.Windows.Forms.ListBox SpellsListBox;
        private System.Windows.Forms.ListBox WeaponsListBox;
        private System.Windows.Forms.ListBox ArmorListBox;
    }
}