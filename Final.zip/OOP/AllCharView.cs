﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace OOP
{
    public partial class AllCharView : Form
    {
        public AllCharView()
        {
            InitializeComponent();
            LoadAllCharacters();
        }

        private void LoadAllCharacters()
        {
            allCharactersGrid.DataSource = DataLoader.LoadAllCharacters();
        }

        private void FilterClassBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void FilterSpeciesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            string selectedClass = FilterClassBox.SelectedItem?.ToString();
            string selectedSpecies = FilterSpeciesBox.SelectedItem?.ToString();

            // If neither filter is selected, load all characters
            if (string.IsNullOrEmpty(selectedClass) && string.IsNullOrEmpty(selectedSpecies))
            {
                allCharactersGrid.DataSource = DataLoader.LoadAllCharacters();
            }
            else
            {
                allCharactersGrid.DataSource = DataLoader.LoadCharactersByFilters(selectedClass, selectedSpecies);
            }
        }


        private void viewButton_Click(object sender, EventArgs e)
        {
            if (allCharactersGrid.SelectedRows.Count > 0)
            {
                string name = allCharactersGrid.SelectedRows[0].Cells["Name"].Value.ToString();
                var displayForm = new CharDisplayForm(name);
                displayForm.ShowDialog();
                LoadAllCharacters();
            }
            else
            {
                MessageBox.Show("Please select a character to view.");
            }
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (allCharactersGrid.SelectedRows.Count > 0)
            {
                string name = allCharactersGrid.SelectedRows[0].Cells["Name"].Value.ToString();
                DataLoader.DeleteCharacter(name);
                MessageBox.Show("Character deleted successfully.");
                LoadAllCharacters();
            }
            else
            {
                MessageBox.Show("Please select a character to delete.");
            }
        }

        private void reloadButton_Click(object sender, EventArgs e)
        {
            LoadAllCharacters();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}