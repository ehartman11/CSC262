﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Updated Species class to include AbilityBoosts and Type for species traits

namespace OOP
{
    public class Species
    {
        public string Name { get; set; }
        public string Type { get; set; } // e.g., "caster" or "warrior"
        public Dictionary<string, int> AbilityBoosts { get; set; } // e.g., {"Strength": 2, "Dexterity": 1}
    }
}

