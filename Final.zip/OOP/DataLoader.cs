﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;

namespace OOP
{
    public static class DataLoader
    {
        private static readonly string connectionString = $"Data Source=C:\\Users\\ephar\\source\\repos\\OOP\\OOP\\CharacterDB.db;Version=3;";

        public static DataTable LoadAllCharacters()
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Characters";
                using (var cmd = new SQLiteCommand(query, conn))
                using (var adapter = new SQLiteDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    return dt;
                }
            }
        }

        public static DataTable LoadCharactersByFilters(string classFilter, string speciesFilter)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Characters WHERE 1=1";

                if (!string.IsNullOrEmpty(classFilter))
                    query += " AND Class = @Class";

                if (!string.IsNullOrEmpty(speciesFilter))
                    query += " AND Species = @Species";

                using (var cmd = new SQLiteCommand(query, conn))
                {
                    if (!string.IsNullOrEmpty(classFilter))
                        cmd.Parameters.AddWithValue("@Class", classFilter);

                    if (!string.IsNullOrEmpty(speciesFilter))
                        cmd.Parameters.AddWithValue("@Species", speciesFilter);

                    using (var adapter = new SQLiteDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public static Character LoadCharacter(string name)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Characters WHERE Name = @Name";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Character character = new Character
                            {
                                Name = reader["Name"].ToString(),
                                Class = reader["Class"].ToString(),
                                Species = reader["Species"].ToString(),
                                Level = Convert.ToInt32(reader["Level"]),
                                Hitpoints = Convert.ToInt32(reader["Hitpoints"]),
                                Strength = Convert.ToInt32(reader["Strength"]),
                                Dexterity = Convert.ToInt32(reader["Dexterity"]),
                                Constitution = Convert.ToInt32(reader["Constitution"]),
                                Intelligence = Convert.ToInt32(reader["Intelligence"]),
                                Wisdom = Convert.ToInt32(reader["Wisdom"]),
                                Charisma = Convert.ToInt32(reader["Charisma"])
                            };
                            return character;
                        }
                        return null;
                    }
                }
            }
        }

        public static void UpdateCharacter(Character character)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string updateQuery = @"
                UPDATE Characters SET 
                    Class = @Class,
                    Species = @Species,
                    Level = @Level,
                    Hitpoints = @Hitpoints,
                    Strength = @Strength,
                    Dexterity = @Dexterity,
                    Constitution = @Constitution,
                    Intelligence = @Intelligence,
                    Wisdom = @Wisdom,
                    Charisma = @Charisma
                WHERE Name = @Name;";

                using (var cmd = new SQLiteCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", character.Name);
                    cmd.Parameters.AddWithValue("@Class", character.Class);
                    cmd.Parameters.AddWithValue("@Species", character.Species);
                    cmd.Parameters.AddWithValue("@Level", character.Level);
                    cmd.Parameters.AddWithValue("@Hitpoints", character.Hitpoints);
                    cmd.Parameters.AddWithValue("@Strength", character.Strength);
                    cmd.Parameters.AddWithValue("@Dexterity", character.Dexterity);
                    cmd.Parameters.AddWithValue("@Constitution", character.Constitution);
                    cmd.Parameters.AddWithValue("@Intelligence", character.Intelligence);
                    cmd.Parameters.AddWithValue("@Wisdom", character.Wisdom);
                    cmd.Parameters.AddWithValue("@Charisma", character.Charisma);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void UpdateCharacter(string name, string className, string species, int level, int hp, int str, int dex, int con, int intl, int wis, int cha)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string updateQuery = @"
            UPDATE Characters SET 
                Class = @Class,
                Species = @Species,
                Level = @Level,
                Hitpoints = @Hitpoints,
                Strength = @Strength,
                Dexterity = @Dexterity,
                Constitution = @Constitution,
                Intelligence = @Intelligence,
                Wisdom = @Wisdom,
                Charisma = @Charisma
            WHERE Name = @Name;";

                using (var cmd = new SQLiteCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Class", className);
                    cmd.Parameters.AddWithValue("@Species", species);
                    cmd.Parameters.AddWithValue("@Level", level);
                    cmd.Parameters.AddWithValue("@Hitpoints", hp);
                    cmd.Parameters.AddWithValue("@Strength", str);
                    cmd.Parameters.AddWithValue("@Dexterity", dex);
                    cmd.Parameters.AddWithValue("@Constitution", con);
                    cmd.Parameters.AddWithValue("@Intelligence", intl);
                    cmd.Parameters.AddWithValue("@Wisdom", wis);
                    cmd.Parameters.AddWithValue("@Charisma", cha);
                    cmd.ExecuteNonQuery();
                }
            }
        }


        public static void DeleteCharacter(string name)
        {

            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string deleteQuery = "DELETE FROM Characters WHERE Name = @Name";
                using (var cmd = new SQLiteCommand(deleteQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public static void SaveCharacterToDatabase(Character character)
        {
            InsertCharacter(character);

            if (character is SpellCaster caster && caster.Spells?.Count > 0)
                InsertSpells(caster);

            if (character is MeleeFighter fighter && fighter.Weapons?.Count > 0)
                InsertWeapons(fighter);

            if (character.Items?.Count > 0)
                InsertItems(character);

            if (character.Notes != null)
                InsertNotes(character);

            if (!string.IsNullOrEmpty(character.Backstory))
                InsertBackstory(character);

            if (character.Bonds != null)
                InsertBonds(character);
        }

        public static void InsertCharacter(Character character)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();

                string query = @"INSERT INTO Characters 
                    (Name, Class, Level, Hitpoints, Species, Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma)
                    VALUES 
                    (@Name, @Class, @Level, @Hitpoints, @Species, @Strength, @Dexterity, @Constitution, @Intelligence, @Wisdom, @Charisma)";

                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", character.Name);
                    cmd.Parameters.AddWithValue("@Class", character.Class);
                    cmd.Parameters.AddWithValue("@Level", character.Level);
                    cmd.Parameters.AddWithValue("@Hitpoints", character.Hitpoints);
                    cmd.Parameters.AddWithValue("@Species", character.Species);
                    cmd.Parameters.AddWithValue("@Strength", character.Strength);
                    cmd.Parameters.AddWithValue("@Dexterity", character.Dexterity);
                    cmd.Parameters.AddWithValue("@Constitution", character.Constitution);
                    cmd.Parameters.AddWithValue("@Intelligence", character.Intelligence);
                    cmd.Parameters.AddWithValue("@Wisdom", character.Wisdom);
                    cmd.Parameters.AddWithValue("@Charisma", character.Charisma);
                    cmd.ExecuteNonQuery();
                }

                using (var checkCmd = new SQLiteCommand("SELECT * FROM Characters", conn))
                using (var reader = checkCmd.ExecuteReader())
                {
                    Console.WriteLine("Characters table contents:");
                    while (reader.Read())
                    {
                        Console.WriteLine($"- ID: {reader["Id"]}, Name: {reader["Name"]}");
                    }
                }
            }
        }


        public static void InsertSpells(SpellCaster caster)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                foreach (string spell in caster.Spells)
                {
                    string query = "INSERT INTO Spells (CharacterId, Name, Level) VALUES ((SELECT Id FROM Characters WHERE Name = @Name), @NameVal, 1)";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", caster.Name);
                        cmd.Parameters.AddWithValue("@NameVal", spell);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public static void InsertWeapons(MeleeFighter fighter)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                foreach (string weapon in fighter.Weapons)
                {
                    string query = "INSERT INTO Weapons (CharacterId, Name, Damage, Type) VALUES ((SELECT Id FROM Characters WHERE Name = @Name), @Weapon, 10, 'Melee')";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", fighter.Name);
                        cmd.Parameters.AddWithValue("@Weapon", weapon);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public static void InsertItems(Character character)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                foreach (string item in character.Items)
                {
                    string query = "INSERT INTO Items (CharacterId, Name, Effect) VALUES ((SELECT Id FROM Characters WHERE Name = @Name), @Item, 'Unknown')";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", character.Name);
                        cmd.Parameters.AddWithValue("@Item", item);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public static void InsertNotes(Character character)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                    string query = "INSERT INTO Notes (CharacterId, Text) VALUES ((SELECT Id FROM Characters WHERE Name = @Name), @Text)";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", character.Name);
                        cmd.Parameters.AddWithValue("@Text", character.Notes);
                        cmd.ExecuteNonQuery();
                    }
            }
        }

        public static void InsertBackstory(Character character)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Backstories (CharacterId, Text) VALUES ((SELECT Id FROM Characters WHERE Name = @Name), @Text)";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", character.Name);
                    cmd.Parameters.AddWithValue("@Text", character.Backstory);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void InsertBonds(Character character)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                    string query = "INSERT INTO Bonds (CharacterId, Text) VALUES ((SELECT Id FROM Characters WHERE Name = @Name), @Text)";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", character.Name);
                        cmd.Parameters.AddWithValue("@Text", character.Bonds);
                        cmd.ExecuteNonQuery();
                    }
            }
        }

        public static void RemoveSpell(string characterName, string spellName)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM Spells WHERE CharacterId = (SELECT Id FROM Characters WHERE Name = @Name) AND Name = @SpellName";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", characterName);
                    cmd.Parameters.AddWithValue("@SpellName", spellName);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void RemoveWeapon(string characterName, string weaponName)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM Weapons WHERE CharacterId = (SELECT Id FROM Characters WHERE Name = @Name) AND Name = @WeaponName";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", characterName);
                    cmd.Parameters.AddWithValue("@WeaponName", weaponName);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void RemoveItem(string characterName, string itemName)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM Items WHERE CharacterId = (SELECT Id FROM Characters WHERE Name = @Name) AND Name = @ItemName";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", characterName);
                    cmd.Parameters.AddWithValue("@ItemName", itemName);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public static void RemoveArmor(string characterName, string armorName)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM Armors WHERE CharacterId = (SELECT Id FROM Characters WHERE Name = @Name) AND Name = @ArmorName";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", characterName);
                    cmd.Parameters.AddWithValue("@ArmorName", armorName);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}

