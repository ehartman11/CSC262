﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace OOP
{
    public partial class CharDisplayForm : Form
    {
        private string selectedCharacterName;

        public CharDisplayForm(string characterName)
        {
            selectedCharacterName = characterName;
            InitializeComponent();
            LoadCharacterData();
        }

        private void LoadCharacterData()
        {
            Character character = DataLoader.LoadCharacter(selectedCharacterName);
            NameLbl.Text = character.Name;
            ClassLbl.Text = character.Class;
            SpeciesLbl.Text = character.Species;
            HpBox.Value = character.Hitpoints;
            LevelBox.Value = character.Level;
            strengthBox.Value = character.Strength;
            DexterityBox.Value = character.Dexterity;
            ConstitutionBox.Value = character.Constitution;
            IntelligenceBox.Value = character.Intelligence;
            WisdomBox.Value = character.Wisdom;
            CharismaBox.Value = character.Charisma;
            SpellsListBox.Items.Clear();
            foreach (var spell in character.Spells)
            {
                SpellsListBox.Items.Add(spell);
            }
            WeaponsListBox.Items.Clear();
            foreach (var weapon in character.Weapons)
            {
                WeaponsListBox.Items.Add(weapon);
            }
            ItemsListBox.Items.Clear();
            foreach (var item in character.Items)
            {
                ItemsListBox.Items.Add(item);
            }
            ArmorListBox.Items.Clear();
            foreach (var armor in character.Armors)
            {
                ArmorListBox.Items.Add(armor);
            }
        }

        private void EditLabel_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Edit button clicked");
            // Make all fields editable
            LevelBox.Enabled = true;
            HpBox.Enabled = true;
            strengthBox.Enabled = true;
            DexterityBox.Enabled = true;
            ConstitutionBox.Enabled = true;
            IntelligenceBox.Enabled = true;
            WisdomBox.Enabled = true;
            CharismaBox.Enabled = true;
            SpellsListBox.Enabled = true;
            WeaponsListBox.Enabled = true;
            ItemsListBox.Enabled = true;
            BackstoryBox.Enabled = true;
            BondBox.Enabled = true;
            NotesBox.Enabled = true;
        }

        private void SaveButton_Click_1(object sender, EventArgs e)
        {
            DataLoader.UpdateCharacter(
            selectedCharacterName,
            ClassLbl.Text,
            SpeciesLbl.Text,
            (int)LevelBox.Value,
            (int)HpBox.Value,
            (int)strengthBox.Value,
            (int)DexterityBox.Value,
            (int)ConstitutionBox.Value,
            (int)IntelligenceBox.Value,
            (int)WisdomBox.Value,
            (int)CharismaBox.Value
);
            LoadCharacterData(); // Reload character data to reflect changes
            MessageBox.Show("Character updated successfully.");
        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            // check to see which selected item is selected from which list then remove it
            if (SpellsListBox.SelectedItem != null)
            {
                string spell = SpellsListBox.SelectedItem.ToString();
                SpellsListBox.Items.Remove(spell);
                DataLoader.RemoveSpell(selectedCharacterName, spell);
            }
            else if (WeaponsListBox.SelectedItem != null)
            {
                string weapon = WeaponsListBox.SelectedItem.ToString();
                WeaponsListBox.Items.Remove(weapon);
                DataLoader.RemoveWeapon(selectedCharacterName, weapon);
            }
            else if (ItemsListBox.SelectedItem != null)
            {
                string item = ItemsListBox.SelectedItem.ToString();
                ItemsListBox.Items.Remove(item);
                DataLoader.RemoveItem(selectedCharacterName, item);
            }
            else if (ArmorListBox.SelectedItem != null)
            {
                string armor = ArmorListBox.SelectedItem.ToString();
                ArmorListBox.Items.Remove(armor);
                DataLoader.RemoveArmor(selectedCharacterName, armor);
            }
        }
    }
}
