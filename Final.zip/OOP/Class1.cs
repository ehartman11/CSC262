﻿using System.Collections.Generic;

namespace OOP
{
    public class Character
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Class { get; set; }
        public int Level { get; set; }
        public int Hitpoints { get; set; }
        public string Species { get; set; }

        public int Strength { get; set; }
        public int Dexterity { get; set; }
        public int Constitution { get; set; }
        public int Intelligence { get; set; }
        public int Wisdom { get; set; }
        public int Charisma { get; set; }

        public string Backstory { get; set; }
        public string Bonds { get; set; }
        public string Notes { get; set; }

        public List<string> Spells { get; set; } = new List<string>();
        public List<string> Weapons { get; set; } = new List<string>();
        public List<string> Items { get; set; } = new List<string>();
        public List<string> Armors { get; set; } = new List<string>();
    }

    public class SpellCaster : Character
    {
        public void AddSpell(string spell)
        {
            if (!Spells.Contains(spell))
                Spells.Add(spell);
        }
    }

    public class MeleeFighter : Character
    {
        public void AddWeapon(string weapon)
        {
            if (!Weapons.Contains(weapon))
                Weapons.Add(weapon);
        }
    }
}
