﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace OOP
{
    public class Database
    {
        private SQLiteConnection connection;

        public Database(string dbPath)
        {
            connection = new SQLiteConnection($"Data Source={dbPath};Version=3;");
            connection.Open();
            new SQLiteCommand("PRAGMA foreign_keys = ON;", connection).ExecuteNonQuery();

            string[] tableCommands = new string[]
            {
                "DROP TABLE IF EXISTS Characters;",
                "DROP TABLE IF EXISTS Spells;",
                "DROP TABLE IF EXISTS Weapons;",
                "DROP TABLE IF EXISTS Armors;",
                "DROP TABLE IF EXISTS Items;",
                "DROP TABLE IF EXISTS CharacterNotes;",

                @"CREATE TABLE IF NOT EXISTS Characters (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name TEXT NOT NULL,
                    Class TEXT NOT NULL,
                    Level INTEGER NOT NULL,
                    Hitpoints INTEGER NOT NULL,
                    Species TEXT NOT NULL,
                    Strength INTEGER NOT NULL,
                    Dexterity INTEGER NOT NULL,
                    Constitution INTEGER NOT NULL,
                    Intelligence INTEGER NOT NULL,
                    Wisdom INTEGER NOT NULL,
                    Charisma INTEGER NOT NULL
                );",

                @"CREATE TABLE IF NOT EXISTS Spells (
                    CharacterId INTEGER,
                    Name TEXT NOT NULL,
                    Level INTEGER NOT NULL,
                    FOREIGN KEY (CharacterId) REFERENCES Characters(Id) ON DELETE CASCADE
                );",

                @"CREATE TABLE IF NOT EXISTS Weapons (
                    CharacterId INTEGER,
                    Name TEXT NOT NULL,
                    Damage INTEGER NOT NULL,
                    Type TEXT NOT NULL,
                    FOREIGN KEY (CharacterId) REFERENCES Characters(Id) ON DELETE CASCADE
                );",

                @"CREATE TABLE IF NOT EXISTS Armors (
                    CharacterId INTEGER,
                    Name TEXT NOT NULL,
                    Defense INTEGER NOT NULL,
                    Type TEXT NOT NULL,
                    FOREIGN KEY (CharacterId) REFERENCES Characters(Id) ON DELETE CASCADE
                );",

                @"CREATE TABLE IF NOT EXISTS Items (
                    CharacterId INTEGER,
                    Name TEXT NOT NULL,
                    Effect TEXT NOT NULL,
                    FOREIGN KEY (CharacterId) REFERENCES Characters(Id) ON DELETE CASCADE
                );",

                @"CREATE TABLE IF NOT EXISTS CharacterNotes (
                    CharacterId INTEGER,
                    Type TEXT CHECK(Type IN ('Backstory', 'Bond', 'Note')),
                    Text TEXT,
                    FOREIGN KEY (CharacterId) REFERENCES Characters(Id) ON DELETE CASCADE
                );"
            };

            foreach (var cmdText in tableCommands)
            {
                using (var cmd = new SQLiteCommand(cmdText, connection))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}