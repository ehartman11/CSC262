﻿namespace OOP
{
    partial class AllCharView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.allCharactersGrid = new System.Windows.Forms.DataGridView();
            this.FilterButton = new System.Windows.Forms.Button();
            this.ClassLbl = new System.Windows.Forms.Label();
            this.SpeciesLbl = new System.Windows.Forms.Label();
            this.FilterClassBox = new System.Windows.Forms.ComboBox();
            this.FilterSpeciesBox = new System.Windows.Forms.ComboBox();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.ReloadButton = new System.Windows.Forms.Button();
            this.ViewButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.allCharactersGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // allCharactersGrid
            // 
            this.allCharactersGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.allCharactersGrid.Location = new System.Drawing.Point(12, 75);
            this.allCharactersGrid.Name = "allCharactersGrid";
            this.allCharactersGrid.Size = new System.Drawing.Size(391, 227);
            this.allCharactersGrid.TabIndex = 0;
            // 
            // FilterButton
            // 
            this.FilterButton.Location = new System.Drawing.Point(22, 31);
            this.FilterButton.Name = "FilterButton";
            this.FilterButton.Size = new System.Drawing.Size(75, 23);
            this.FilterButton.TabIndex = 1;
            this.FilterButton.Text = "Filter";
            this.FilterButton.UseVisualStyleBackColor = true;
            // 
            // ClassLbl
            // 
            this.ClassLbl.AutoSize = true;
            this.ClassLbl.Location = new System.Drawing.Point(124, 15);
            this.ClassLbl.Name = "ClassLbl";
            this.ClassLbl.Size = new System.Drawing.Size(32, 13);
            this.ClassLbl.TabIndex = 2;
            this.ClassLbl.Text = "Class";
            // 
            // SpeciesLbl
            // 
            this.SpeciesLbl.AutoSize = true;
            this.SpeciesLbl.Location = new System.Drawing.Point(258, 17);
            this.SpeciesLbl.Name = "SpeciesLbl";
            this.SpeciesLbl.Size = new System.Drawing.Size(45, 13);
            this.SpeciesLbl.TabIndex = 3;
            this.SpeciesLbl.Text = "Species";
            // 
            // FilterClassBox
            // 
            this.FilterClassBox.FormattingEnabled = true;
            this.FilterClassBox.Location = new System.Drawing.Point(127, 33);
            this.FilterClassBox.Name = "FilterClassBox";
            this.FilterClassBox.Size = new System.Drawing.Size(121, 21);
            this.FilterClassBox.TabIndex = 4;
            // 
            // FilterSpeciesBox
            // 
            this.FilterSpeciesBox.FormattingEnabled = true;
            this.FilterSpeciesBox.Location = new System.Drawing.Point(261, 33);
            this.FilterSpeciesBox.Name = "FilterSpeciesBox";
            this.FilterSpeciesBox.Size = new System.Drawing.Size(121, 21);
            this.FilterSpeciesBox.TabIndex = 5;
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(22, 322);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(75, 23);
            this.DeleteButton.TabIndex = 6;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseVisualStyleBackColor = true;
            // 
            // ReloadButton
            // 
            this.ReloadButton.Location = new System.Drawing.Point(113, 322);
            this.ReloadButton.Name = "ReloadButton";
            this.ReloadButton.Size = new System.Drawing.Size(75, 23);
            this.ReloadButton.TabIndex = 7;
            this.ReloadButton.Text = "Reload";
            this.ReloadButton.UseVisualStyleBackColor = true;
            // 
            // ViewButton
            // 
            this.ViewButton.Location = new System.Drawing.Point(205, 322);
            this.ViewButton.Name = "ViewButton";
            this.ViewButton.Size = new System.Drawing.Size(75, 23);
            this.ViewButton.TabIndex = 8;
            this.ViewButton.Text = "View / Edit";
            this.ViewButton.UseVisualStyleBackColor = true;
            // 
            // AllCharView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 361);
            this.Controls.Add(this.ViewButton);
            this.Controls.Add(this.ReloadButton);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.FilterSpeciesBox);
            this.Controls.Add(this.FilterClassBox);
            this.Controls.Add(this.SpeciesLbl);
            this.Controls.Add(this.ClassLbl);
            this.Controls.Add(this.FilterButton);
            this.Controls.Add(this.allCharactersGrid);
            this.Name = "AllCharView";
            this.Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)(this.allCharactersGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView allCharactersGrid;
        private System.Windows.Forms.Button FilterButton;
        private System.Windows.Forms.Label ClassLbl;
        private System.Windows.Forms.Label SpeciesLbl;
        private System.Windows.Forms.ComboBox FilterClassBox;
        private System.Windows.Forms.ComboBox FilterSpeciesBox;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Button ReloadButton;
        private System.Windows.Forms.Button ViewButton;
    }
}