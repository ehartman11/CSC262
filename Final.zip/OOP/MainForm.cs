﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace OOP
{
    public partial class MainForm : Form
    {
        private List<Species> speciesList;
        private Species selectedSpecies;
        private Character selectedCharacter;
        private List<string> tools = new List<string>();

        public MainForm()
        {
            InitializeComponent();
            LoadSpeciesData();
            speciesBox.SelectedIndexChanged += speciesBox_SelectedIndexChanged;
        }

        private void LoadSpeciesData()
        {
            string json = File.ReadAllText(@"C:\Users\ephar\source\repos\OOP\OOP\species.json");
            speciesList = JsonSerializer.Deserialize<List<Species>>(json);
            speciesBox.DataSource = speciesList;
            speciesBox.DisplayMember = "Name";
        }

        private void speciesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedSpecies = speciesBox.SelectedItem as Species;
            if (selectedSpecies == null) return;

            UpdateAbilityLabels(selectedSpecies);
            UpdateSidePanel(selectedSpecies.Type);
            sideButton.Enabled = false;
            tools.Clear();
            SideListBox.Items.Clear();
        }

        private void UpdateAbilityLabels(Species species)
        {
            var boosts = species.AbilityBoosts;
            var keys = boosts.Keys.ToList();

            ability_1_Label.Text = keys.Count > 0 ? keys[0] : "";
            ability_1_boost_label.Text = keys.Count > 0 ? boosts[keys[0]].ToString() : "";
            ability_2_Label.Text = keys.Count > 1 ? keys[1] : "";
            ability_2_boost_label.Text = keys.Count > 1 ? boosts[keys[1]].ToString() : "";
        }

        private void UpdateSidePanel(string type)
        {
            sideComboBox.Items.Clear();
            sideLabel.Text = type == "caster" ? "Caster: Available Spells" : "Melee: Available Weapons";
            string[] items = type == "caster"
                ? new[] { "Fireball", "Lightning Bolt", "Magic Missile" }
                : new[] { "Sword", "Axe", "Spear" };

            sideComboBox.Items.AddRange(items);
        }

        private void sideComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            sideButton.Enabled = sideComboBox.SelectedItem != null;
        }

        private void sideButton_Click(object sender, EventArgs e)
        {
            if (sideComboBox.SelectedItem == null) return;

            string tool = sideComboBox.SelectedItem.ToString();
            if (!tools.Contains(tool))
            {
                tools.Add(tool);
                SideListBox.Items.Add(tool);
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (selectedSpecies == null)
            {
                MessageBox.Show("Please select a species.");
                return;
            }

            Character character;

            if (selectedCharacter != null)
            {
                character = selectedCharacter;
            }
            else
            {
                switch (selectedSpecies.Type)
                {
                    case "caster":
                        character = new SpellCaster();
                        break;
                    case "warrior":
                        character = new MeleeFighter();
                        break;
                    default:
                        MessageBox.Show("Unsupported species type.");
                        return;
                }
            }


            if (character == null)
            {
                MessageBox.Show("Unsupported species type.");
                return;
            }

            character.Name = nameBox.Text;
            character.Class = classComboBox.Text;
            character.Species = selectedSpecies.Name;
            character.Level = (int)levelBox.Value;
            character.Hitpoints = (int)hitPointsBox.Value;
            character.Strength = (int)strengthBox.Value;
            character.Dexterity = (int)dexterityBox.Value;
            character.Constitution = (int)constitutionBox.Value;
            character.Intelligence = (int)intelligenceBox.Value;
            character.Wisdom = (int)wisdomBox.Value;
            character.Charisma = (int)charismaBox.Value;

            foreach (var tool in tools)
            {
                if (character is SpellCaster caster) caster.AddSpell(tool);
                if (character is MeleeFighter warrior) warrior.AddWeapon(tool);
                Console.WriteLine($"Added {tool} to {character.Name}");
            }

            SaveCharacterToDatabase(character);
            ClearFormFields();
        }

        private void SaveCharacterToDatabase(Character character)
        {
            DataLoader.SaveCharacterToDatabase(character);
            savedCharacterBox.Items.Add(character.Name);
        }

        private void ClearFormFields()
        {
            nameBox.Clear();
            classComboBox.SelectedIndex = -1;
            speciesBox.SelectedIndex = -1;
            levelBox.Value = 1;
            hitPointsBox.Value = 1;
            strengthBox.Value = dexterityBox.Value = constitutionBox.Value = 0;
            intelligenceBox.Value = wisdomBox.Value = charismaBox.Value = 0;

            ability_1_Label.Text = ability_2_Label.Text = "";
            ability_1_boost_label.Text = ability_2_boost_label.Text = "";
            sideComboBox.Items.Clear();
            SideListBox.Items.Clear();
            tools.Clear();
        }

        private void viewButton_Click(object sender, EventArgs e)
        {
            string name = savedCharacterBox.SelectedItem?.ToString();
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Select a character.");
                return;
            }

            var form = new CharDisplayForm(name);
            form.ShowDialog();
        }

        private void ViewAllCharButton_Click(object sender, EventArgs e)
        {
            var form = new AllCharView();
            form.ShowDialog();
        }
    }
}
