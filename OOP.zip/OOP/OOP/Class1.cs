﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace OOP
{

    // Species class to manage species and their ability boosts
    public class Species
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public Dictionary<string, int> AbilityBoosts { get; set; }
    };

    // Class to represent a character
    public class Character
    {
        // Protected properties of the character
        private string _name;
        private string _class;
        private string _species;
        private int _level;
        private int _hitpoints;

        // Dictionary to store character attributes
        private Dictionary<string, int> _attributes = new Dictionary<string, int>()
        {
            { "Strength", 0 },
            { "Dexterity", 0 },
            { "Constitution", 0 },
            { "Intelligence", 0 },
            { "Wisdom", 0 },
            { "Charisma", 0 }
        };

        // Accessing properties for character attributes
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Class
        {
            get { return _class; }
            set { _class = value; }
        }
        public string Species
        {
            get { return _species; }
            set { _species = value; }
        }
        public int Level
        {
            get { return _level; }
            set { _level = value; }
        }
        public int Hitpoints
        {
            get { return _hitpoints; }
            set { _hitpoints = value; }
        }

        // Method to get an attribute value: If _attributes contains the attribute, return its value; otherwise, return 0
        public int GetAttribute(string attr) => _attributes.ContainsKey(attr) ? _attributes[attr] : 0;

        // Method to set an attribute value: If _attributes contains the attribute, update its value
        public void SetAttribute(string attr, int value)
        {
            if (_attributes.ContainsKey(attr))
                _attributes[attr] = value;
        }

        // Method to add a spell to the character's spell list
        public virtual void AddSpell(string spell) { }

        // Method to add a weapon to the character's weapon list
        public virtual void AddWeapon(string weapon) { }

        // Method to display character details
        public virtual void display()
        {
            string txt = $"Character Details: \n Name: {Name}\n Class: {Class}\n Species: {Species}\n Level: {Level}\n Hitpoints: {Hitpoints}\n ";
            foreach (var attr in _attributes)
            {
                txt = txt + $"{attr.Key}: {attr.Value}\n ";
            }
            MessageBox.Show(txt, "Character Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Overloaded method to display specific character details
        public virtual void display(int num)
        {
            string txt = $"Character Details: \n Name: {Name}\n Level: {Level}\n Hitpoints: {Hitpoints}\n ";
            foreach (var attr in _attributes)
            {
                txt = txt + $"{attr.Key}: {attr.Value}\n ";
            }
            MessageBox.Show(txt, "Character Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    };

    // Subclass representing a spell caster. Inherits from the Character base class
    public class SpellCaster : Character
    {
        // Protected properties specific to spell casters
        private int _spellSlots;
        private int _spellLevel;
        private List<string> _spellsKnown = new List<string>();

        // Accessing properties for spell caster attributes
        public int SpellSlots
        {
            get { return _spellSlots; }
            set { _spellSlots = value; }
        }
        public int SpellLevel
        {
            get { return _spellLevel; }
            set { _spellLevel = value; }
        }
        public List<string> SpellsKnown
        {
            get { return _spellsKnown; }
            set { _spellsKnown = value; }
        }

        // Method to add a spell to the spell caster's spell list
        public override void AddSpell(string spell)
        {
            if (!_spellsKnown.Contains(spell))
            {
                _spellsKnown.Add(spell);
            }
        }

        // Method to display spell caster details
        public override void display()
        {
            string txt = $"Character Details: \n\n Name: {Name}\n\n Class: {Class}\t Species: {Species}\n Level: {Level}\t Hitpoints: {Hitpoints}\n\n ";
            foreach (var attr in new[] {"Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma"})
            {
                txt = txt + $"{attr}: {GetAttribute(attr)}\n ";
            }
            txt = txt + $"\nSpell Slots: {SpellSlots}\n Spell Level: {SpellLevel}\n Spells Known: {string.Join(", ", SpellsKnown)}\n ";
            MessageBox.Show(txt, "Character Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Overloaded method to display specific spell caster details
        public override void display(int num)
        {
            string txt = $"Spell Slots: {SpellSlots}\n Spell Level: {SpellLevel}\n Spells Known: {string.Join(", ", SpellsKnown)}\n ";
            MessageBox.Show(txt, "Spells Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    };

    // Subclass representing a Melee Fighter. Inherits from the Character base class
    public class MeleeFighter : Character
    {
        // Protected properties specific to melee fighters
        private int _armorClass;
        private int _attackBonus;
        private List<string> _weapons = new List<string>();

        // Accessing properties for melee fighter attributes
        public int ArmorClass
        {
            get { return _armorClass; }
            set { _armorClass = value; }
        }
        public int AttackBonus
        {
            get { return _attackBonus; }
            set { _attackBonus = value; }
        }
        public List<string> Weapons
        {
            get { return _weapons; }
            set { _weapons = value; }
        }

        // Method to add a weapon to the melee fighter's weapons list
        public override void AddWeapon(string tool)
        {
            if (!_weapons.Contains(tool))
            {
                _weapons.Add(tool);
            }
        }

        // Method to display melee fighter details
        public override void display()
        {
            string txt = $"Character Details: \n\n Name: {Name}\n\n Class: {Class}\t Species: {Species}\n Level: {Level}\t Hitpoints: {Hitpoints}\n\n ";
            foreach (var attr in new[] { "Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma" })
            {
                txt = txt + $"{attr}: {GetAttribute(attr)}\n ";
            }
            txt = txt + $"\nArmor Class: {ArmorClass}\n Attack Bonus: {AttackBonus}\n Weapons: {string.Join(", ", Weapons)}\n ";
            MessageBox.Show(txt, "Character Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Overloaded method to display specific melee fighter details
        public override void display(int num)
        {
            string txt = $"Armor Class: {ArmorClass}\n Attack Bonus: {AttackBonus}\n Weapons: {string.Join(", ", Weapons)}\n ";
            MessageBox.Show(txt, "Melee Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    };
}