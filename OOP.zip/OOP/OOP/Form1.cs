﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Text.Json;
using System.Diagnostics.Eventing.Reader;


namespace OOP
{
    // Main form class
    public partial class Form1 : Form
    {
        // Fields to store species data, character data, and UI elements
        string json;
        List<Species> speciesList;
        List<Character> savedCharacters = new List<Character>();
        List<string> tools = new List<string>();
        Species species = new Species();
        Character selectedCharacter;

        // Constructor
        public Form1()
        {
            InitializeComponent();
            json = File.ReadAllText(@"C:\Users\ephar\source\repos\OOP\OOP\species.json");
            speciesList = JsonSerializer.Deserialize<List<Species>>(json);
        }

        // Method to load ability boosts based on selected species
        private void loadAbilityLabels(string selected)
        {

            // Display ability boosts
            foreach (Species s in speciesList)
            {
                if (s.Name == selected)
                {
                    species = s;
                    break;
                }
            };
            var boosts = species.AbilityBoosts;

            var keys = boosts.Keys.ToList();

            // Display up to two boosts, if available
            if (keys.Count > 0)
            {
                ability_1_Label.Text = keys[0];
                ability_1_boost_label.Text = boosts[keys[0]].ToString();
            }
            if (keys.Count > 1)
            {
                ability_2_Label.Text = keys[1];
                ability_2_boost_label.Text = boosts[keys[1]].ToString();
            }
            else
            {
                ability_2_Label.Text = "";
                ability_2_boost_label.Text = "";
            }

            updateSidePanel(species.Type);
        }

        // Method to update the side panel based on character type
        private void updateSidePanel(string type)
        {
            sideComboBox.Items.Clear();
            if (type == "caster")
            {
                sideLabel.Text = "Caster: Available Spells";
                sideComboBox.Items.Add("Fireball");
                sideComboBox.Items.Add("Lightning Bolt");
                sideComboBox.Items.Add("Magic Missile");
            }
            else if (type == "warrior")
            {
                sideLabel.Text= "Melee: Available Weapons";
                sideComboBox.Items.Add("Sword");
                sideComboBox.Items.Add("Axe");
                sideComboBox.Items.Add("Spear");
            }
        }

        // Event handler for species dropdown selection change
        private void speciesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check to see if the speciesBox has a selected item, 
            // and if so, get the selected species and its ability boosts
            // Display the boosts in the appropriate labels
            if (speciesBox.SelectedItem != null)
            {
                string displaySpecies = speciesBox.SelectedItem.ToString();
                loadAbilityLabels(displaySpecies);
                sideButton.Enabled = false;
                sideComboBox.SelectedValue = null;
                tools.Clear();
                sideTextBox.Clear();
            }
            else
            {
                ability_1_Label.Text = "";
                ability_1_boost_label.Text = "";
                ability_2_Label.Text = "";
                ability_2_boost_label.Text = "";
            }
        }

        // Clear form fields after saving a character
        private void ClearFormFields()
        {
            nameBox.Clear();
            classComboBox.SelectedIndex = -1;
            speciesBox.SelectedIndex = -1;
            levelBox.Value = 1;
            hitPointsBox.Value = 1;

            strengthBox.Value = 0;
            dexterityBox.Value = 0;
            constitutionBox.Value = 0;
            intelligenceBox.Value = 0;
            wisdomBox.Value = 0;
            charismaBox.Value = 0;

            ability_1_Label.Text = "";
            ability_1_boost_label.Text = "";
            ability_2_Label.Text = "";
            ability_2_boost_label.Text = "";
        }

        // Event handler for save button click
        private void saveButton_Click(object sender, EventArgs e)
        {
            // Find the selected species
            Species species = speciesList.FirstOrDefault(s => s.Name == speciesBox.SelectedItem?.ToString());

            if (species == null)
            {
                MessageBox.Show("Please select a valid species.");
                return;
            }

            Character character;

            // Create appropriate subclass
            if (selectedCharacter != null)
            {
                character = selectedCharacter;
            }
            else if (species.Type == "caster")
            {
                character = new SpellCaster();
            }
            else if (species.Type == "warrior")
            {
                character = new MeleeFighter();
            }
            else
            {
                MessageBox.Show("Unsupported species type.");
                return;
            }

            // Set basic attributes
            character.Name = nameBox.Text;
            character.Class = classComboBox.Text;
            character.Species = species.Name;
            character.Level = (int)levelBox.Value;
            character.Hitpoints = (int)hitPointsBox.Value;

            character.SetAttribute("Strength", (int)strengthBox.Value);
            character.SetAttribute("Dexterity", (int)dexterityBox.Value);
            character.SetAttribute("Constitution", (int)constitutionBox.Value);
            character.SetAttribute("Intelligence", (int)intelligenceBox.Value);
            character.SetAttribute("Wisdom", (int)wisdomBox.Value);
            character.SetAttribute("Charisma", (int)charismaBox.Value);

            // Add tools
            foreach (string tool in tools)
            {
                if (species.Type == "caster" && character is SpellCaster caster)
                {
                    caster.AddSpell(tool);
                }
                else if (species.Type == "warrior" && character is MeleeFighter warrior)
                {
                    warrior.AddWeapon(tool);
                }
            }

            // Save character
            if (selectedCharacter == null)
            {
                savedCharacters.Add(character);
                savedCharacterBox.Items.Add(character.Name);
            }

            // Clear UI
            ClearFormFields();
            sideTextBox.Text = "";
            sideButton.Enabled = false;
            sideComboBox.SelectedItem = null;
        }


        // Event handler for view button click
        private void viewButton_Click(object sender, EventArgs e)
        {
            /* Using the name selected in the saved characters dropdown menu, 
               Ensure that the selected name is not null or empty,
               Find the associated character in the saved characters list, 
               Then fill the form's fields with that character object's attributes.
             */
            string selectedName = savedCharacterBox.SelectedItem?.ToString(); 
            if (string.IsNullOrWhiteSpace(selectedName))
            {
                MessageBox.Show("Please select a character from the dropdown.");
                return;
            }

            selectedCharacter = savedCharacters.FirstOrDefault(c => c.Name == selectedName);
            if (selectedCharacter == null)
            {
                MessageBox.Show("Character not found.");
                return;
            }

            nameBox.Text = selectedCharacter.Name;
            classComboBox.Text = selectedCharacter.Class;
            speciesBox.Text = selectedCharacter.Species;
            levelBox.Value = selectedCharacter.Level;
            hitPointsBox.Value = selectedCharacter.Hitpoints;

            strengthBox.Value = selectedCharacter.GetAttribute("Strength");
            dexterityBox.Value = selectedCharacter.GetAttribute("Dexterity");
            constitutionBox.Value = selectedCharacter.GetAttribute("Constitution");
            intelligenceBox.Value = selectedCharacter.GetAttribute("Intelligence");
            wisdomBox.Value = selectedCharacter.GetAttribute("Wisdom");
            charismaBox.Value = selectedCharacter.GetAttribute("Charisma");

            // Load ability boosts for the selected species
            loadAbilityLabels(selectedCharacter.Species);           
            sideTextBox.Clear();
            allCharInfoButton.Enabled = true;
            charSynopsisButton.Enabled = true;
        }

        // Event handler for side combo box selection change
        private void sideComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (sideComboBox.SelectedIndex != 0)
            {
                sideButton.Enabled = true;
            }
        }

        // Event handler for adding spells or weapons to the tools textBox
        private void sideButton_Click(object sender, EventArgs e)
        {
            sideTextBox.Text = sideTextBox.Text + "\n" +sideComboBox.SelectedItem.ToString();
            tools.Add(sideComboBox.SelectedItem.ToString());
        }

        // Event handler for side text box text change
        private void allCharInfoButton_Click(object sender, EventArgs e)
        {
            selectedCharacter.display();
        }

        // Event handler for viewing character abilities button click
        private void charSynopsisButton_Click(object sender, EventArgs e)
        {
            selectedCharacter.display(1);
        }
    }
}
